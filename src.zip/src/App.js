import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';

// Global styles
import './App.css';

// =====================
// LANDING PAGE COMPONENTS
// =====================
import Navbar from './LandingPage/components/Navbar';
import Footer from './LandingPage/components/Footer';

// Landing Page - Pages
import Home from './LandingPage/pages/Home';
import Login from './LandingPage/pages/Login';
import Register from './LandingPage/pages/Register';
import Search from './LandingPage/pages/Search';
import Dashboard from './LandingPage/pages/Dashboard';
import Agents from './LandingPage/pages/Agents';
import Contact from './LandingPage/pages/LandingContact';
import PrivacyPolicy from './LandingPage/pages/PrivacyPolicy';
import TermsConditions from './LandingPage/pages/TermCondition';

// =====================
// ADMIN PAGES
// =====================
import AdminLogin from './LandingPage/pages/admin/AdminLogin';
import AdminDashboard from './LandingPage/pages/admin/AdminDashboard';
import AdminProperties from './LandingPage/pages/admin/AdminProperties';
import AdminUsers from './LandingPage/pages/admin/AdminUsers';
import AdminAgents from './LandingPage/pages/admin/AdminAgents';
import AdminSupport from './LandingPage/pages/admin/AdminSupport';
import AdminSettings from './LandingPage/pages/admin/AdminSettings';

// =====================
// USER (BUYER) DASHBOARD
// =====================
import BuyerNavbar from './UserDashboard/components/Navbar';
import BuyerFooter from './UserDashboard/components/Footer';
import BuyerHome from './UserDashboard/pages/BuyerHome';
import BuyerProfile from './UserDashboard/pages/BuyerProfile';
import BuyerContactPage from './UserDashboard/pages/BuyerContactPage';
import ViewDetailsPage from './UserDashboard/pages/ViewDetailsPage';
import SearchResults from './UserDashboard/pages/SearchResults';
import CityFilteredBuy from './UserDashboard/pages/Cityfilteredbuy';
import CityFilteredRent from './UserDashboard/pages/Cityfilteredrent';
import CityProjects from './UserDashboard/pages/Cityprojects';
import ChatUs from './UserDashboard/pages/ChatUs';
import './UserDashboard/styles/global.css';

// =====================
// SELLER/AGENT DASHBOARD
// =====================
import SellerDashboard from './Agent-dashboard/Agent-dashboard';

// =====================
// LAYOUT COMPONENTS
// =====================

// Layout for Landing Pages (public pages with Navbar/Footer)
const LandingLayout = ({ children }) => {
  return (
    <>
      <Navbar />
      <main>{children}</main>
      <Footer />
    </>
  );
};

// Layout for Buyer Dashboard
const BuyerDashboardLayout = ({ children }) => {
  return (
    <div className="buyer-dashboard-app">
      <BuyerNavbar />
      <main className="buyer-main-content">{children}</main>
      <BuyerFooter />
    </div>
  );
};

// =====================
// MAIN APP COMPONENT
// =====================
function App() {
  return (
    <Router>
      <div className="App">
        <Routes>
          
          {/* ==================== */}
          {/* PUBLIC LANDING PAGES */}
          {/* ==================== */}
          <Route path="/" element={<LandingLayout><Home /></LandingLayout>} />
          <Route path="/login" element={<LandingLayout><Login /></LandingLayout>} />
          <Route path="/register" element={<LandingLayout><Register /></LandingLayout>} />
          <Route path="/search" element={<LandingLayout><Search /></LandingLayout>} />
          <Route path="/Dashboard" element={<LandingLayout><Dashboard /></LandingLayout>} />
          <Route path="/agents" element={<LandingLayout><Agents /></LandingLayout>} />
          <Route path="/contact" element={<LandingLayout><Contact /></LandingLayout>} />
          <Route path="/privacy-policy" element={<LandingLayout><PrivacyPolicy /></LandingLayout>} />
          <Route path="/terms-conditions" element={<LandingLayout><TermsConditions /></LandingLayout>} />

          {/* ==================== */}
          {/* ADMIN ROUTES */}
          {/* ==================== */}
          <Route path="/admin/login" element={<AdminLogin />} />
          <Route path="/admin/dashboard" element={<AdminDashboard />} />
          <Route path="/admin/properties" element={<AdminProperties />} />
          <Route path="/admin/users" element={<AdminUsers />} />
          <Route path="/admin/agents" element={<AdminAgents />} />
          <Route path="/admin/support" element={<AdminSupport />} />
          <Route path="/admin/settings" element={<AdminSettings />} />

          {/* ==================== */}
          {/* BUYER DASHBOARD ROUTES */}
          {/* ==================== */}
          <Route path="/buyer-dashboard" element={<BuyerDashboardLayout><BuyerHome /></BuyerDashboardLayout>} />
          <Route path="/buyer-dashboard/home" element={<BuyerDashboardLayout><BuyerHome /></BuyerDashboardLayout>} />
          <Route path="/buyer-dashboard/buy" element={<BuyerDashboardLayout><CityFilteredBuy /></BuyerDashboardLayout>} />
          <Route path="/buyer-dashboard/rent" element={<BuyerDashboardLayout><CityFilteredRent /></BuyerDashboardLayout>} />
          <Route path="/buyer-dashboard/projects" element={<BuyerDashboardLayout><CityProjects /></BuyerDashboardLayout>} />
          <Route path="/buyer-dashboard/buyercontactpage" element={<BuyerDashboardLayout><BuyerContactPage /></BuyerDashboardLayout>} />
          <Route path="/buyer-dashboard/profile" element={<BuyerDashboardLayout><BuyerProfile /></BuyerDashboardLayout>} />
          <Route path="/buyer-dashboard/search" element={<BuyerDashboardLayout><SearchResults /></BuyerDashboardLayout>} />
          <Route path="/buyer-dashboard/details/:id" element={<BuyerDashboardLayout><ViewDetailsPage /></BuyerDashboardLayout>} />
          <Route path="/buyer-dashboard/ChatUs" element={<BuyerDashboardLayout><ChatUs /></BuyerDashboardLayout>} />
          
          {/* Alternative paths for buyer (without prefix) */}
          <Route path="/buy" element={<BuyerDashboardLayout><CityFilteredBuy /></BuyerDashboardLayout>} />
          <Route path="/rent" element={<BuyerDashboardLayout><CityFilteredRent /></BuyerDashboardLayout>} />
          <Route path="/projects" element={<BuyerDashboardLayout><CityProjects /></BuyerDashboardLayout>} />
          <Route path="/BuyerProfile" element={<BuyerDashboardLayout><BuyerProfile /></BuyerDashboardLayout>} />
          <Route path="/details/:id" element={<BuyerDashboardLayout><ViewDetailsPage /></BuyerDashboardLayout>} />

          {/* ==================== */}
          {/* SELLER/AGENT DASHBOARD */}
          {/* ==================== */}
          <Route path="/seller-dashboard" element={<SellerDashboard />} />
          <Route path="/Agent-dashboard" element={<SellerDashboard />} />

        </Routes>
      </div>
    </Router>
  );
}

export default App;